package startup;

public class Starter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
