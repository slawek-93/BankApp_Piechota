package users;

import java.util.ArrayList;

public class Branchlist {
private ArrayList<Branch> branchlist = new ArrayList<Branch> ();
public void addBranch (Branch branch) 
	{
		branchlist.add(branch);
	}
public void Show_branches()
	{
		for (int i=0;i<branchlist.size();i++) 
		{ String name = branchlist.get(i).getName();
			System.out.println("element " + i + " " + name); 
		}	

	}
}
