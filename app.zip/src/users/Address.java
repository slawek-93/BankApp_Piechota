package users;

public class Address {
private String street;
private int number;
private String mail;

public String getStreet() {
	return street;
}
public void setStreet(String street) {
	this.street = street;
}
public int getNumber() {
	return number;
}
public void setNumber(int number) {
	this.number = number;
}
public String getMail() {
	return mail;
}
public void setMail(String mail) {
	this.mail = mail;
}
}
