package users;

public class Accountant extends Employee {

	public Accountant(String name, String surname, Integer id) {
		super(name, surname, id);
		// TODO Auto-generated constructor stub
	}

}
