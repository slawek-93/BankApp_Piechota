package users;

public class Test_first_timr {

	public static void main(String[] args) {
		//Branches
		Branch Branch_0 = new Branch();
		Branchlist Branchlist_0 = new Branchlist();
		
		//workers
		Cashier Cashier_1 = new Cashier("Jack", "Sparrow", 0);
		Boss Boss_1 = new Boss("Marilyn", "Manson", 0);
		
		//customers
	
		
		//lets start it works
		Branch_0.addEmployee(Cashier_1);
		Branch_0.setName("zerowa");
		Branch_0.setAddress(null);
		Branchlist_0.addBranch(Branch_0);
		Boss_1.setBranchlist(Branchlist_0);
		Boss_1.Show_Branches();
	}

}
