package users;

public class Cashier extends Employee {

	public Cashier(String name, String surname, Integer id) {
		super(name, surname, id);
		// TODO Auto-generated constructor stub
	}

}
