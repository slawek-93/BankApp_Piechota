package users;

public class Security extends Employee {

	public Security(String name, String surname, Integer id) {
		super(name, surname, id);
		// TODO Auto-generated constructor stub
	}

}
