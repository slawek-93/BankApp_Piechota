package users;

public class Manager extends Employee {

	private Branchlist branchlist;
	
	public void Show_Branches()
	{
		branchlist.Show_branches();
	}
	
	
	
	public Manager(String name, String surname, Integer id) {
		super(name, surname, id);
		// TODO Auto-generated constructor stub
	}
	
}
