package users;

import java.util.ArrayList;

public class Branch {
	private Address address;
	private String name;
	private ArrayList<Employee> employeeList = new ArrayList<Employee>();
		public void addEmployee (Employee employee) {
		employeeList.add(employee);
	}
		public Address getAddress() {
			return address;
		}
		public void setAddress(Address address) {
			this.address = address;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}


}
