package users;

public class Admin extends Employee {

	public Admin(String name, String surname, Integer id) {
		super(name, surname, id);
		// TODO Auto-generated constructor stub
	}

}
